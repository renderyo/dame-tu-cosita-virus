$folder = [Environment]::GetFolderPath("Desktop") # You can change this path
$numFiles = 30

for ($i = 1; $i -le $numFiles; $i++) {
    $baseName = "DAME TU COSITA AH $i"

    # Create empty .exe (just a placeholder)
    New-Item -Path "$folder\$baseName.exe" -ItemType File -Force | Out-Null

    # Create empty .bat
    New-Item -Path "$folder\$baseName.bat" -ItemType File -Force | Out-Null

    # Create empty .ps1
    New-Item -Path "$folder\$baseName.ps1" -ItemType File -Force | Out-Null
}

[System.Windows.Forms.MessageBox]::Show("$numFiles files created on your Desktop!", "DAME TU COSITA", 'OK', 'Information')
